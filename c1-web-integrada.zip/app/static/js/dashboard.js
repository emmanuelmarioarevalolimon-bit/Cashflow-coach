(() => {

  const toast = document.getElementById("toast");
  let toastTimer;

  function showToast(message) {
    window.clearTimeout(toastTimer);
    toast.textContent = message;
    toast.hidden = false;
    toastTimer = window.setTimeout(() => {
      toast.hidden = true;
    }, 2800);
  }

  document.querySelectorAll(".disabled-feature").forEach((button) => {
    button.addEventListener("click", () => {
      showToast(`${button.dataset.feature} no está disponible en este MVP del hackathon.`);
    });
  });

  document.getElementById("logoutButton").addEventListener("click", () => {
    c1Logout();
  });

  const menuButton = document.querySelector(".mobile-menu-button");
  if (menuButton) {
    menuButton.addEventListener("click", () => document.body.classList.toggle("sidebar-open"));
  }

  document.addEventListener("click", (event) => {
    if (
      document.body.classList.contains("sidebar-open") &&
      !event.target.closest(".sidebar") &&
      !event.target.closest(".mobile-menu-button")
    ) {
      document.body.classList.remove("sidebar-open");
    }
  });
})();
