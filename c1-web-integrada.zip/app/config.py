"""Configuration is read afresh. A local .env takes precedence over inherited AI_* values.
No keys, hashes of keys, provider bodies or filesystem paths are returned by status().
"""
from __future__ import annotations
from dataclasses import dataclass
import hashlib
import os
from pathlib import Path
import re
from threading import Lock
from urllib.parse import urlsplit
from .version import VERSION

PROJECT_DIR = Path(__file__).resolve().parents[1]
ENV_FILE = PROJECT_DIR / '.env'
DEFAULT_URL = 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions'
DEFAULT_MODEL = 'gemini-3.8-flash'
_PLACEHOLDERS = {'', 'TU_CLAVE_NUEVA', 'PEGA_AQUI_TU_CLAVE_NUEVA_DE_GEMINI', 'tu_clave_nueva', 'reemplaza_con_una_clave_nueva', 'replace_with_your_key'}
_lock = Lock()
_last: dict[str, object] = {}


def read_env() -> dict[str, str]:
    values: dict[str, str] = {}
    if ENV_FILE.is_file():
        for line in ENV_FILE.read_text(encoding='utf-8-sig').splitlines():
            line = line.strip()
            if not line or line.startswith('#') or '=' not in line:
                continue
            key, val = line.split('=', 1)
            values[key.strip()] = val.strip().strip('"').strip("'")
    return values


@dataclass(frozen=True)
class AIConfig:
    api_url: str
    api_key: str
    model: str
    timeout_seconds: int

    @property
    def configured(self) -> bool:
        return bool(self.api_url and self.model and self.api_key not in _PLACEHOLDERS)

    @property
    def identity(self) -> str:
        return hashlib.sha256(f'{self.api_url}\0{self.model}\0{self.api_key}'.encode()).hexdigest()


def get_ai_config() -> AIConfig:
    values = read_env()
    def get(name: str, default: str = '') -> str:
        return values.get(name, os.getenv(name, default)).strip()
    try:
        timeout = max(5, min(60, int(get('AI_TIMEOUT_SECONDS', '60'))))
    except ValueError:
        timeout = 60
    key = get('AI_API_KEY') or get('GEMINI_API_KEY')
    return AIConfig(get('AI_API_URL', DEFAULT_URL), key,
                    get('AI_MODEL', DEFAULT_MODEL), timeout)


def _is_gemini(config: AIConfig) -> bool:
    try:
        return config.api_url.rstrip('/') == DEFAULT_URL
    except ValueError:
        return False


def record_status(config: AIConfig, *, verified: bool, error: str | None = None) -> None:
    with _lock:
        _last.clear()
        _last.update(identity=config.identity, verified=verified, error=error)


def ai_status() -> dict[str, object]:
    config = get_ai_config()
    missing = []
    if config.api_key in _PLACEHOLDERS: missing.append('AI_API_KEY')
    if not config.api_url: missing.append('AI_API_URL')
    if not config.model: missing.append('AI_MODEL')
    error = None
    if config.configured and not _is_gemini(config):
        error = 'AI_API_URL no es el endpoint oficial admitido de Gemini.'
    if config.model and not re.fullmatch(r'gemini-[a-zA-Z0-9_.-]+', config.model):
        error = 'AI_MODEL debe ser un identificador de modelo Gemini válido.'
    with _lock:
        last = _last.copy() if _last.get('identity') == config.identity else {}
    error = error or last.get('error')
    verified = bool(last.get('verified')) and not error
    mode = 'error' if error else 'external' if verified else 'configured' if config.configured else 'unconfigured'
    labels = {'error': 'Gemini: error visible', 'external': 'Gemini verificado',
              'configured': 'Gemini configurado · pendiente de prueba',
              'unconfigured': 'Gemini sin configurar · chat desactivado'}
    return {'version': VERSION, 'configured': config.configured, 'mode': mode,
            'label': labels[mode], 'verified': verified,
            'model': config.model if re.fullmatch(r'gemini-[a-zA-Z0-9_.-]+', config.model or '') else None,
            'missing': missing, 'error': error}
